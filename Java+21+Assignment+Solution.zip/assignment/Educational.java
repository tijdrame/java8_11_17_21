package java21.assignment;

public sealed interface Educational permits Faculty{}
