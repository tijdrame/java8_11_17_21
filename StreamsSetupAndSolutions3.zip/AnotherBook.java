package j8.ocp.java_stream_api;

public class AnotherBook {    
    private String title;
    private String genre;    
    public AnotherBook(String title, String genre){         
        this.title = title;
        this.genre = genre;    
    }     //accessors not shown 

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }
    
}